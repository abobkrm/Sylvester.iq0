--[[ 
▀▄ ▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀ 
▀▄ ▄▀                                      ▀▄ ▄▀ 
▀▄ ▄▀    BY bkr               ▀▄ ▄▀ 
▀▄ ▄▀   BY bkr(@pl_pnl)      ▀▄ ▄▀ 
▀▄ ▄▀ JUST WRITED by bkr   ▀▄ ▄▀ 
▀▄ ▄▀                   كتم الوسائط            ▀▄ ▄▀ 
▀▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀ 
—]] 
do 

local function pre_process(msg) 
local bkr = msg['id'] 
  local user = msg.from.id 
local chat = msg.to.id 
    local bkr = 'mate:'..msg.to.id 
    if redis:get(bkr) and msg.media and not is_momod(msg) then 

            delete_msg(msg.id, ok_cb, false) 
local test = "  كبدي ["..msg.from.first_name.."]".."\n".."يمنع نشر صور فيديوهات صوتيات وكافة الميديا هنا ان تكرر الامر سوف تجبرني على طردك يرجى اتباع القوانين ☝️".."\n".." 👮 معرفك: @"..(msg.from.username or " ") 
reply_msg(bkr, test, ok_cb, true) 

end 

        return msg 
    end 

local function bkr(msg, matches) 
local plbkr 
= msg['id'] 

    if matches[1] == 'قفل الوسائط'  and is_momod(msg) then 
                    local bkr= 'mate:'..msg.to.id 
                    redis:set(bkr, true) 
local king = '☑️ تم قفل 🔒 جميع الوسائط  \nيا  : @'..msg.from.username..'\n ايديك☂ : '.. msg.from.id..'\n' 
reply_msg(bkr, king, ok_cb, true) 
elseif matches[1] == 'قفل الوسائط' and not is_momod(msg) then 
local king = 'للـمـشـرفـيـن فـقـط 👮حبي ' 
reply_msg(bkr, king, ok_cb, true) 
  elseif is_momod(msg) and matches[1] == 'فتح الوسائط' then 
      local bkr= 'mate:'..msg.to.id 
      redis:del(bkr) 
local king = '☑️ تم فتح جميع الوسائط 🔓🔔 \nيا  : @'..msg.from.username..'\nايدي   : '.. msg.from.id..'\n' 
reply_msg(bkr, king, ok_cb, true) 
elseif matches[1] == 'فتح الوسائط' and not is_momod(msg) then 
local king= 'للـمـشـرفـيـن فـقـط?😈حبي ' 
reply_msg(bkr, king, ok_cb, true) 
end 
end 

return { 
    patterns = { 
    "^(قفل الوسائط)$", 
    "^(فتح الوسائط)$", 
  }, 
run = bkr, 
    pre_process = pre_process 
} 

end 

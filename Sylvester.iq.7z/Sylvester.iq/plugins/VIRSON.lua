 do
  
  function bkr(msg, matches)
  local reply_id = msg['id']
    local n = ' ☺ اسم السورس سلفستر \n مطور السورس @pl_pl \n\n تم صنع سورس علئ موقع (github.com) v1'  reply_msg(reply_id, n, ok_cb, false)
  end
  
  return {
    patterns = {
  "^(الاصدار)$",
    }, 
    run = bkr,
  }
  
  end
